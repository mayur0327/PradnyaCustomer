import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing/app-routing.module';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { DisplayComponent } from './display/display.component';
import {CustomerService} from './services/customer.service';
import { SearchComponent } from './search/search.component'


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    DisplayComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    AppRoutingModule,
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
