import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { RegisterComponent } from 'src/app/register/register.component';
import { DisplayComponent } from 'src/app/display/display.component';


import { CommonModule } from '@angular/common';
const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'register', component: RegisterComponent, pathMatch: 'full' },
  { path: 'display', component: DisplayComponent, pathMatch: 'full' },
  { path: '**', redirectTo: 'register', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
