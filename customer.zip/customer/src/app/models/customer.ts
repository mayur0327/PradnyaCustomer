export class Customer {
    public custId:number;
    public custName:String;
    public custAddress:String;
    public custContact:number;

}
