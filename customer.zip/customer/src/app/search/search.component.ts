import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  custSearched: Customer;
  constructor(private customerService:CustomerService) { 
    this.custSearched = new Customer();
  }

 
  ngOnInit() {
  }

}
