import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  customerArr:Customer[];
  customerToEdit:Customer;
  isEditing:boolean;

  constructor(private custService:CustomerService) {
    this.customerArr = [];
    this.customerToEdit = new Customer()
   }

  ngOnInit() {
    this.customerArr = this.custService.getCustomer();
  }
  edit(id:number)
  {
    this.isEditing = true;
    this.customerToEdit = this.custService.edit(id);
  }
  delete(index: number) {
    this.custService.delete(index);
   }
 

}
