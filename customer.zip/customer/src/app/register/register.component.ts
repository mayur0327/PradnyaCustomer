import { Component, OnInit,Input,Output, EventEmitter  } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {
   //to create new employee or edit it
   @Input() customerEntry: Customer;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

  //initilize it
  constructor(private custService: CustomerService) {
    this.customerEntry = new Customer();
  }

  add() {
    this.custService.store(this.customerEntry);
    this.customerEntry = new Customer();
  }

  update()
  {
    this.isEditing = false;
    this.customerEntry= new Customer();
    this.edited.emit();
  }

  ngOnInit() {
  }

}
